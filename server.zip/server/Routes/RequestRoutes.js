const express = require("express");
const route = express.Router();

const { addRequest, getRequests, updateRequestStatus  } = require("../Controller/RequestController");
const auth = require("../Middleware/Auth");

// ADD REQUEST
route.post("/addrequest", auth, addRequest);

// GET ALL REQUESTS
route.get("/getrequests", getRequests);

route.put("/updatestatus/:id", updateRequestStatus);

module.exports = route;