const Request = require("../Models/RequestModel");

// ADD REQUEST
const addRequest = async (req, res) => {
  try {
    const data = new Request({
      propertyId: req.body.propertyId,
      tenantName: req.body.tenantName,
      user: req.user.id   // ✅ NEW LINE
    });

    const result = await data.save();

    res.send({
      success: true,
      message: "Request added successfully",
      data: result
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error adding request"
    });
  }
};

// GET ALL REQUESTS
const getRequests = async (req, res) => {
  try {
    const data = await Request.find().populate("propertyId");
    res.send(data);
  } catch (error) {
    console.log(error);
    res.send("Error fetching requests");
  }
};

// UPDATE REQUEST STATUS
const updateRequestStatus = async (req, res) => {
  try {
    const id = req.params.id;

    const updated = await Request.findByIdAndUpdate(
      id,
      { status: req.body.status },
      { new: true }
    );

    res.send(updated);
  } catch (error) {
    console.log(error);
    res.send("Error updating request");
  }
};

module.exports = {
  addRequest,
  getRequests,
  updateRequestStatus
};